package com.dbschool.hw4.repositories;

import com.dbschool.hw4.entity.Orderdetails;
import org.springframework.data.repository.CrudRepository;

public interface OrderdetailsRepository extends CrudRepository<Orderdetails, Integer> {
}
