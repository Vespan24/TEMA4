package com.dbschool.hw4.controllers;

public class PaymentsController {
}
