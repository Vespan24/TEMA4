package com.dbschool.hw4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hw4ApplicationTests {

    @Test
    void contextLoads() {

    }

}
